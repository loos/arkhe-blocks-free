// Arkheブロックのアイコンカラー
export const iconColor = ' #000';

// ブロック設定を取得するためのAPIパス
// export const arkheApiPath = '/wp/v2/arkhe-blocks-settings';

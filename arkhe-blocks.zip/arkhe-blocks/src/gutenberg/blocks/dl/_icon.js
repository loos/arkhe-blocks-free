export default (
	<svg viewBox='0 0 56 56'>
		<rect x='4' y='4' width='2' height='6' />
		<rect x='10' y='5' width='42' height='4' />
		<rect x='4' y='31' width='2' height='6' />
		<rect x='10' y='32' width='42' height='4' />
		<path d='M52,25H10V13h42V25z M12,23h38v-8H12V23z' />
		<path d='M52,52H10V40h42V52z M12,50h38v-8H12V50z' />
	</svg>
);

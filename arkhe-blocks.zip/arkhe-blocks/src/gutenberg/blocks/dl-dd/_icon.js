export default (
	<svg viewBox='0 0 56 56'>
		<path d='M53,36H7V20h46V36z M9,34h42V22H9V34z' />
	</svg>
);

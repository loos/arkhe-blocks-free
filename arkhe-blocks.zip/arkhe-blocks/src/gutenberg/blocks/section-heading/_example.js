export default {
	attributes: {
		content: 'Sectin Heading',
		subContent: 'sub text',
	},
};

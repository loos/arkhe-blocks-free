export default (
	<svg viewBox='0 0 56 56'>
		<rect x='3' y='20' width='50' height='16' />
	</svg>
);

// dt: (
// 	<svg viewBox='0 0 56 56'>
// 		<rect x='3' y='20' width='50' height='16' />
// 	</svg>
// ),
// dd: (
// 	<svg viewBox='0 0 56 56'>
// 		<path d='M53,36H7V20h46V36z M9,34h42V22H9V34z' />
// 	</svg>
// ),

export default (
	<svg viewBox='0 0 56 56'>
		<path d='M28,20H7H3v16h4h21h25V20H28z M51,34H28V22h23V34z' />
	</svg>
);

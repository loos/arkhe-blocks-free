/**
 * extension
 */
import './extension/headbar.js';
import { createContext } from '@wordpress/element';

const SliderContext = createContext();
window.arkbContext = { SliderContext };
